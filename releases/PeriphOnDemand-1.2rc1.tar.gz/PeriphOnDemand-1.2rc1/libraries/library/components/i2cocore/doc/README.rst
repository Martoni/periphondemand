i2cocore
--------

Ask fabien.marteau@armadeus.com to document this
