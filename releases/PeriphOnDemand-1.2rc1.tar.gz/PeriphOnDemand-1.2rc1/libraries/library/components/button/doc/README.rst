Button
------

Ask fabien.marteau@armadeus.com to document this
