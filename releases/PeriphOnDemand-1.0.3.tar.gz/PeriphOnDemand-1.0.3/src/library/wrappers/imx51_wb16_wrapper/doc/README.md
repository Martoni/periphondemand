imx51_wb16_wrapper component
============================

This component is designed to convert WEIM bus from i.MX51
to Wisbone 16 bits bus.

FPGA component
--------------

No register

ARMadeus linux driver
---------------------

There is no driver for wrapper, do write a driver using this bus use
'platform_bus'.
