 and component
================

simple logic and function

FPGA component
--------------

