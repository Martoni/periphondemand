Or component
------------

simple logic or function

FPGA component
^^^^^^^^^^^^^^
