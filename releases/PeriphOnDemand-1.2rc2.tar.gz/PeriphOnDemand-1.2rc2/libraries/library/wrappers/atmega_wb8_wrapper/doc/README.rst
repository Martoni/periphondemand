Atmega wb8 wrapper
------------------

Ask fabien.marteau@armadeus.com to document this
