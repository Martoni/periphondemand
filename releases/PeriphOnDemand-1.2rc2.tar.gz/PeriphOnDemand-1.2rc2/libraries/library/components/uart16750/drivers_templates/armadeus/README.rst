To compile this driver from here:
---------------------------------
    make ARCH=arm CROSS_COMPILE=$PWD/../../../../../buildroot/build_arm/staging_dir/bin/arm-linux-

To install this driver:
-----------------------
Copy resulting *.ko files on your target rootfs

