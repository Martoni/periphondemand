Rstext syscon
-------------

Ask fabien.marteau@armadeus.com to document this
